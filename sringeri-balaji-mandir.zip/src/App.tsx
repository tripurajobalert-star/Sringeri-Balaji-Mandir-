import { motion } from "motion/react";
import { 
  MapPin, 
  Clock, 
  Plane, 
  Train, 
  Car, 
  Star, 
  Facebook, 
  Instagram, 
  Youtube, 
  Twitter, 
  ArrowRight,
  ChevronDown,
  Info,
  Calendar,
  Image as ImageIcon,
  Menu,
  X,
  Flower2,
  Home
} from "lucide-react";
import { useState, useEffect } from "react";

// --- Components ---

const Ticker = () => (
  <div className="bg-crimson-dark text-gold-light py-2 overflow-hidden relative z-50 border-b-2 border-gold">
    <div className="whitespace-nowrap inline-block animate-ticker font-heading text-xs tracking-[1.5px]">
      🪔 JAI SRI BALAJI 🙏 &nbsp;&nbsp; ⭐ SRINGERI BALAJI MANDIR — KAILASHAHAR, UNAKOTI, TRIPURA &nbsp;&nbsp; 🌸 DARSHAN TIMINGS: 6:00 AM – 12:00 PM | 4:00 PM – 8:30 PM &nbsp;&nbsp; 🎉 BRAHMOTSAVAM: CELEBRATED WITH GREAT GRANDEUR &nbsp;&nbsp; 🛕 BUILT IN SOUTH INDIAN DRAVIDIAN STYLE ON THE BANKS OF MANU RIVER &nbsp;&nbsp; 📍 PECHARDAHAR, BILASPUR G.P., FATIKROY, UNAKOTI DIST., TRIPURA — PIN: 799279 &nbsp;&nbsp; 🙏 OM NAMO VENKATESAYA &nbsp;&nbsp;
    </div>
  </div>
);

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav className={`sticky top-0 z-[1000] transition-all duration-300 ${scrolled ? 'bg-crimson-dark/95 shadow-xl' : 'bg-crimson-dark'} border-b-3 border-gold px-6 md:px-10 py-3 flex items-center justify-between`}>
      <a href="#" className="flex items-center gap-3">
        <span className="text-3xl animate-pulse">🛕</span>
        <div className="font-heading text-gold text-base leading-tight tracking-wider">
          Sringeri Balaji Mandir
          <span className="block text-[10px] text-cream tracking-[2px]">Kailashahar · Tripura</span>
        </div>
      </a>

      <div className="hidden md:flex gap-2">
        {["About", "Deity", "Timings", "Festivals", "Reach", "Contact"].map((item) => (
          <a 
            key={item} 
            href={`#${item.toLowerCase()}`} 
            className="text-cream hover:text-gold font-heading text-xs tracking-widest px-4 py-2 transition-colors relative group"
          >
            {item}
            <span className="absolute bottom-0 left-1/2 w-0 h-0.5 bg-gold transition-all duration-300 group-hover:w-4/5 -translate-x-1/2" />
          </a>
        ))}
      </div>

      <button className="md:hidden text-gold" onClick={() => setIsOpen(!isOpen)}>
        {isOpen ? <X size={28} /> : <Menu size={28} />}
      </button>

      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-full left-0 w-full bg-crimson-dark border-b-3 border-gold p-6 flex flex-col gap-4 md:hidden"
        >
          {["About", "Deity", "Timings", "Festivals", "Reach", "Contact"].map((item) => (
            <a 
              key={item} 
              href={`#${item.toLowerCase()}`} 
              onClick={() => setIsOpen(false)}
              className="text-cream hover:text-gold font-heading text-sm tracking-widest"
            >
              {item}
            </a>
          ))}
        </motion.div>
      )}
    </nav>
  );
};

const Hero = () => (
  <section id="home" className="relative min-h-[100vh] flex items-center justify-center overflow-hidden bg-gradient-to-b from-crimson-dark via-dark-brown to-[#0D0500]">
    <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_50%,rgba(212,175,55,0.05)_0%,transparent_50%),radial-gradient(circle_at_80%_20%,rgba(255,107,0,0.05)_0%,transparent_40%),radial-gradient(circle_at_60%_80%,rgba(139,26,26,0.1)_0%,transparent_50%)]" />
    
    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[400px] border-3 border-gold/20 border-t-0 rounded-b-[250px]" />
    
    <motion.div 
      animate={{ rotate: 360 }}
      transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
      className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full border-2 border-gold/10"
    />

    <div className="relative z-10 text-center px-6 max-w-4xl">
      <motion.span 
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="text-7xl text-gold block mb-6 drop-shadow-[0_0_20px_rgba(212,175,55,0.6)]"
      >
        ॐ
      </motion.span>
      
      <motion.p 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="font-heading text-xs tracking-[6px] text-saffron-light uppercase mb-6"
      >
        🙏 Sri Venkateswara Swamy · Sringeri Sharada Peetham 🙏
      </motion.p>
      
      <motion.h1 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="font-display text-4xl md:text-7xl text-gold leading-tight mb-4 drop-shadow-[0_0_40px_rgba(212,175,55,0.5)]"
      >
        Sringeri Balaji Mandir
      </motion.h1>
      
      <motion.p 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.7 }}
        className="font-display text-lg md:text-2xl text-saffron-light mb-8"
      >
        श्रृंगेरी बालाजी मन्दिर — কৈলাশহর
      </motion.p>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.9 }}
        className="flex items-center justify-center gap-5 mb-8"
      >
        <div className="h-px w-20 md:w-32 bg-gradient-to-r from-transparent via-gold to-transparent" />
        <span className="text-2xl text-gold">🪷</span>
        <div className="h-px w-20 md:w-32 bg-gradient-to-r from-transparent via-gold to-transparent" />
      </motion.div>

      <motion.p 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.1 }}
        className="font-heading text-sm tracking-[3px] text-cream mb-12"
      >
        📍 Pechardahar, Kailashahar · Unakoti District · Tripura — 799279
      </motion.p>

      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 1.3 }}
        className="flex flex-wrap gap-5 justify-center"
      >
        <a href="#about" className="bg-gradient-to-br from-gold-dark via-gold to-gold-dark text-dark font-heading text-xs tracking-[2px] px-8 py-4 rounded shadow-lg hover:shadow-gold/30 hover:-translate-y-0.5 transition-all uppercase">
          Explore Temple
        </a>
        <a href="#timings" className="border-1.5 border-gold text-gold font-heading text-xs tracking-[2px] px-8 py-4 rounded hover:bg-gold/10 hover:-translate-y-0.5 transition-all uppercase">
          Darshan Timings
        </a>
      </motion.div>
    </div>

    <motion.div 
      animate={{ y: [0, -8, 0] }}
      transition={{ duration: 2, repeat: Infinity }}
      className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-gold font-heading text-[10px] tracking-[2px]"
    >
      <span>SCROLL</span>
      <ChevronDown size={16} />
    </motion.div>
  </section>
);

const StatsBar = () => (
  <div className="bg-gradient-to-r from-crimson-dark to-dark-brown border-y-3 border-gold">
    <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 text-center py-10 px-6 gap-6">
      {[
        { val: "⭐ 4.5", label: "Devotee Rating" },
        { val: "365", label: "Days Open" },
        { val: "1000s", label: "Annual Devotees" },
        { val: "8 km", label: "From Town Centre" }
      ].map((stat, i) => (
        <motion.div 
          key={i}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className={`p-5 ${i !== 3 ? 'md:border-r border-gold/30' : ''}`}
        >
          <span className="font-display text-3xl text-gold block leading-none">{stat.val}</span>
          <div className="font-heading text-[10px] tracking-[3px] text-cream mt-2 uppercase">{stat.label}</div>
        </motion.div>
      ))}
    </div>
  </div>
);

const About = () => (
  <section id="about" className="bg-marble py-20 px-6">
    <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
      <motion.div 
        initial={{ x: -50, opacity: 0 }}
        whileInView={{ x: 0, opacity: 1 }}
        viewport={{ once: true }}
        className="relative"
      >
        <div className="bg-gradient-to-br from-crimson-dark to-dark-brown p-1 rounded-lg shadow-2xl">
          <div className="bg-gradient-to-br from-cream-dark to-cream rounded-md h-[450px] flex flex-col items-center justify-center relative overflow-hidden">
            <span className="text-9xl drop-shadow-xl animate-pulse">🛕</span>
            <div className="mt-5 bg-gradient-to-br from-crimson-dark to-dark-brown text-gold font-heading text-xs tracking-[2px] px-8 py-3 rounded text-center">
              Sri Tirupati Balaji<br/>
              <span className="text-[10px] opacity-80">Pechardahar • Kailashahar</span>
            </div>
            <span className="absolute top-4 left-4 text-2xl text-gold-dark/40">✦</span>
            <span className="absolute bottom-4 right-4 text-2xl text-gold-dark/40">✦</span>
          </div>
        </div>
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute -bottom-5 -right-5 w-24 h-24 bg-gradient-to-br from-gold-dark to-gold rounded-full flex flex-col items-center justify-center text-dark font-heading text-[10px] text-center tracking-tighter shadow-xl"
        >
          <Flower2 size={24} className="mb-1" />
          <span>Sringeri<br/>Peetham</span>
        </motion.div>
      </motion.div>

      <motion.div 
        initial={{ x: 50, opacity: 0 }}
        whileInView={{ x: 0, opacity: 1 }}
        viewport={{ once: true }}
      >
        <h3 className="font-heading text-xs tracking-[4px] text-saffron uppercase mb-2">Sacred Temple of Northeast India</h3>
        <h2 className="font-display text-3xl md:text-4xl text-crimson-dark mb-6 leading-tight">Sringeri Balaji Mandir — A Divine Abode in Tripura's Heart</h2>
        
        <p className="text-sm md:text-base leading-relaxed text-[#5C3D2E] mb-5 font-light">
          The <strong>Sringeri Balaji Mandir</strong>, also known as the <em>Tirupati Balaji Temple — Pechardahar</em>, 
          is a magnificent South Indian-style temple nestled on the serene banks of the <strong>Manu River</strong> 
          at Pechardahar, under Bilaspur Gram Panchayat in Fatikroy Assembly Constituency, 
          <strong>Unakoti District, Tripura</strong>.
        </p>

        <p className="text-sm md:text-base leading-relaxed text-[#5C3D2E] mb-5 font-light">
          This sacred temple beautifully replicates the grandeur of South Indian <strong>Dravidian architecture</strong>, 
          bringing the divine presence of <strong>Lord Venkateswara (Balaji)</strong> to the spiritually rich land of 
          Northeast India. Inaugurated by the Chief Minister of Tripura, this temple stands as a landmark pilgrimage site.
        </p>

        <div className="grid grid-cols-2 gap-4 mt-8">
          {[
            { icon: "🏛️", text: "Dravidian Style" },
            { icon: "🌊", text: "Manu Riverbank" },
            { icon: "📿", text: "Sringeri Peetham" },
            { icon: "🎉", text: "Brahmotsavam" }
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3 bg-crimson/5 border border-gold/30 p-3 rounded-md font-heading text-xs text-crimson-dark tracking-wider">
              <span>{item.icon}</span> {item.text}
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  </section>
);

const Deity = () => (
  <section id="deity" className="bg-gradient-to-b from-crimson-dark to-[#3D0E0E] py-20 px-6">
    <div className="max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <span className="font-heading text-xs tracking-[5px] text-saffron-light uppercase block mb-3">Divine Presence</span>
        <h2 className="font-display text-3xl md:text-4xl text-gold mb-4">Principal Deities</h2>
        <div className="flex items-center justify-center gap-4">
          <div className="h-px w-20 bg-gradient-to-r from-transparent to-gold-dark" />
          <span className="text-xl text-gold">🪷</span>
          <div className="h-px w-20 bg-gradient-to-l from-transparent to-gold-dark" />
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {[
          { 
            icon: "🙏", 
            name: "Sri Venkateswara", 
            alias: "Balaji · Govinda · Srinivasa",
            desc: "The presiding deity — Lord Venkateswara, the form of Vishnu worshipped at Tirumala. Known as the Lord of Seven Hills, Balaji is the wish-fulfiller and the most revered Vaishnava deity."
          },
          { 
            icon: "🌸", 
            name: "Goddess Padmavathi", 
            alias: "Alamelu Manga · Sri Devi",
            desc: "The divine consort of Lord Venkateswara, Padmavathi Devi, born from a lotus flower, is an incarnation of Goddess Lakshmi. She bestows prosperity and devotion upon her devotees."
          },
          { 
            icon: "🕉️", 
            name: "Sharada Devi", 
            alias: "Goddess of Learning · Sringeri",
            desc: "Associated with the Sringeri Sharada Peetham founded by Adi Shankaracharya, Goddess Sharada embodies knowledge and wisdom. The Sringeri connection gives this temple a unique lineage."
          }
        ].map((deity, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.2 }}
            className="bg-white/5 border border-gold/25 rounded-xl p-10 text-center hover:-translate-y-2 transition-all group relative overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-gold to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-500" />
            <span className="text-6xl mb-4 block">{deity.icon}</span>
            <h3 className="font-display text-xl text-gold mb-2">{deity.name}</h3>
            <span className="font-heading text-[10px] tracking-[3px] text-saffron-light uppercase mb-4 block">{deity.alias}</span>
            <p className="text-sm leading-relaxed text-cream/70">{deity.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const Timings = () => (
  <section id="timings" className="bg-cream-dark py-20 px-6">
    <div className="max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <span className="font-heading text-xs tracking-[5px] text-saffron uppercase block mb-3">Plan Your Visit</span>
        <h2 className="font-display text-3xl md:text-4xl text-crimson-dark mb-4">Darshan & Puja Timings</h2>
        <div className="flex items-center justify-center gap-4">
          <div className="h-px w-20 bg-gradient-to-r from-transparent to-gold-dark" />
          <span className="text-xl text-gold">🪷</span>
          <div className="h-px w-20 bg-gradient-to-l from-transparent to-gold-dark" />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-10">
        {[
          {
            title: "Morning Darshan",
            icon: "🌅",
            rows: [
              { s: "🪔 Suprabhatam", t: "6:00 AM" },
              { s: "🌸 Thomala Seva", t: "6:30 AM" },
              { s: "🙏 Nivedyam", t: "7:00 AM" },
              { s: "🔔 Morning Aarti", t: "7:30 AM" },
              { s: "🛕 General Darshan", t: "6:00 – 12:00 PM" },
              { s: "🚫 Mid-day Break", t: "12:00 – 4:00 PM" }
            ]
          },
          {
            title: "Evening Darshan",
            icon: "🌇",
            rows: [
              { s: "🕌 Temple Reopens", t: "4:00 PM" },
              { s: "🌼 Vesara Seva", t: "4:30 PM" },
              { s: "🪔 Evening Aarti", t: "6:30 PM" },
              { s: "🛕 General Darshan", t: "4:00 – 8:30 PM" },
              { s: "🔔 Ekantha Seva", t: "8:30 PM" },
              { s: "📅 All Days Open", t: "365 Days" }
            ]
          }
        ].map((card, i) => (
          <motion.div 
            key={i}
            initial={{ x: i === 0 ? -50 : 50, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="bg-white rounded-xl overflow-hidden shadow-2xl border border-gold/20"
          >
            <div className="bg-gradient-to-br from-crimson-dark to-dark-brown p-6 flex items-center gap-4">
              <span className="text-3xl">{card.icon}</span>
              <div>
                <h3 className="font-heading text-lg text-gold tracking-wider">{card.title}</h3>
                <span className="text-xs text-cream opacity-70">Daily Schedule</span>
              </div>
            </div>
            <div className="p-8">
              {card.rows.map((row, j) => (
                <div key={j} className="flex justify-between items-center py-3 border-b border-dashed border-gold/30 last:border-none">
                  <span className="font-heading text-xs text-crimson-dark tracking-wider">{row.s}</span>
                  <span className="font-heading text-xs text-saffron font-bold">{row.t}</span>
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      <motion.div 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="mt-8 bg-crimson/5 border border-gold/30 rounded-lg p-6 text-center font-heading text-xs text-crimson-dark tracking-wider"
      >
        ⚠️ <strong>Note:</strong> Timings may vary during special festivals, Brahmotsavam, and public holidays.
      </motion.div>
    </div>
  </section>
);

const Festivals = () => (
  <section id="festivals" className="bg-marble py-20 px-6">
    <div className="max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <span className="font-heading text-xs tracking-[5px] text-saffron uppercase block mb-3">Sacred Celebrations</span>
        <h2 className="font-display text-3xl md:text-4xl text-crimson-dark mb-4">Festivals & Special Events</h2>
        <div className="flex items-center justify-center gap-4">
          <div className="h-px w-20 bg-gradient-to-r from-transparent to-gold-dark" />
          <span className="text-xl text-gold">🪷</span>
          <div className="h-px w-20 bg-gradient-to-l from-transparent to-gold-dark" />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {[
          { icon: "🎉", title: "Brahmotsavam", month: "Annual · Grand Celebration", desc: "The grandest annual festival of the temple, celebrated with elaborate rituals, processions, and thousands of devotees." },
          { icon: "🌟", title: "Vaikunta Ekadasi", month: "January", desc: "The Vaikunta Dwaram is symbolically opened at dawn. Devotees observe fasting and night vigil seeking moksha." },
          { icon: "🪔", title: "Deepavali", month: "Oct – Nov", desc: "The festival of lights is celebrated with thousands of lamps illuminating the entire temple premises." },
          { icon: "🌸", title: "Sri Rama Navami", month: "March – April", desc: "The birth anniversary of Lord Rama is celebrated with processions and special abhishekam." },
          { icon: "🛕", title: "Navaratri", month: "Sept – Oct", desc: "Nine nights of divine celebration with Golu, Lakshmi, Saraswati, and Durga puja." },
          { icon: "💫", title: "Monthly Ekadasi", month: "Monthly", desc: "Every Ekadasi, special abhishekam, archana, and Satyanarayan Katha are performed." }
        ].map((fest, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex gap-5 bg-white rounded-lg p-7 shadow-lg border-l-4 border-saffron hover:translate-x-1 transition-all"
          >
            <span className="text-4xl shrink-0">{fest.icon}</span>
            <div>
              <span className="text-[10px] tracking-[2px] text-saffron font-heading uppercase mb-2 block">{fest.month}</span>
              <h4 className="font-heading text-base text-crimson-dark mb-2 tracking-wide">{fest.title}</h4>
              <p className="text-xs leading-relaxed text-[#7B5740]">{fest.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const Reach = () => (
  <section id="reach" className="bg-gradient-to-br from-dark to-dark-brown py-20 px-6">
    <div className="max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <span className="font-heading text-xs tracking-[5px] text-saffron-light uppercase block mb-3">Journey to the Divine</span>
        <h2 className="font-display text-3xl md:text-4xl text-gold mb-4">How to Reach</h2>
        <div className="flex items-center justify-center gap-4">
          <div className="h-px w-20 bg-gradient-to-r from-transparent to-gold-dark" />
          <span className="text-xl text-gold">🪷</span>
          <div className="h-px w-20 bg-gradient-to-l from-transparent to-gold-dark" />
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {[
          { 
            icon: <Plane size={48} className="text-gold" />, 
            mode: "By Air", 
            dist: "Kailashahar Airport ~8 km",
            desc: "The nearest airport is Kailashahar Airport (IXH), just 8–10 km away. Agartala Airport (IXA) is the main hub at ~180 km."
          },
          { 
            icon: <Train size={48} className="text-gold" />, 
            mode: "By Train", 
            dist: "Kumarghat ~26 km",
            desc: "Nearest station is Kumarghat on the Lumding–Sabroom section. Dharmanagar is another option (~19.6 km)."
          },
          { 
            icon: <Car size={48} className="text-gold" />, 
            mode: "By Road", 
            dist: "Kailashahar Town ~8 km",
            desc: "Located at Pechardahar on the Kumarghat–Kailashahar Road. Agartala is ~141 km (approx. 3.5 hrs)."
          }
        ].map((reach, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-white/5 border border-gold/20 rounded-xl p-10 text-center hover:bg-gold/5 hover:-translate-y-1 transition-all"
          >
            <div className="flex justify-center mb-4">{reach.icon}</div>
            <h3 className="font-heading text-lg text-gold mb-3 tracking-wider">{reach.mode}</h3>
            <p className="text-sm leading-relaxed text-cream/60 mb-4">{reach.desc}</p>
            <span className="inline-block bg-gold/15 border border-gold/30 text-gold-light font-heading text-[10px] tracking-widest px-4 py-2 rounded-full">
              {reach.dist}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const Footer = () => (
  <footer className="bg-dark border-t-3 border-gold">
    <div className="max-w-7xl mx-auto px-6 py-16 grid md:grid-cols-4 gap-12">
      <div className="md:col-span-2">
        <h2 className="font-display text-xl text-gold mb-4">🛕 Sringeri Balaji Mandir</h2>
        <p className="text-sm leading-relaxed text-cream/50 mb-6 max-w-md">
          A sacred South Indian-style temple on the banks of Manu River in Pechardahar, Kailashahar, 
          Unakoti District, Tripura — bringing the divine blessings of Lord Venkateswara (Balaji) 
          to the devotees of Northeast India.
        </p>
        <div className="flex gap-3">
          {[Facebook, Instagram, Youtube, Twitter].map((Icon, i) => (
            <a key={i} href="#" className="w-10 h-10 rounded-full border border-gold/40 flex items-center justify-center text-gold hover:bg-gold/15 hover:border-gold transition-all">
              <Icon size={18} />
            </a>
          ))}
        </div>
      </div>

      <div>
        <h3 className="font-heading text-xs tracking-[3px] text-gold uppercase mb-6 pb-3 border-b border-gold/20">Quick Links</h3>
        <ul className="space-y-3">
          {["About", "Deity", "Timings", "Festivals", "Reach", "Contact"].map((link) => (
            <li key={link}>
              <a href={`#${link.toLowerCase()}`} className="text-cream/50 hover:text-gold text-sm transition-colors flex items-center gap-2 group">
                <ArrowRight size={12} className="text-saffron opacity-0 group-hover:opacity-100 transition-opacity" />
                {link}
              </a>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h3 className="font-heading text-xs tracking-[3px] text-gold uppercase mb-6 pb-3 border-b border-gold/20">Nearby Places</h3>
        <ul className="space-y-3">
          {["Unakoti Rock Carvings", "Kailashahar Town", "Laxmi Narayan Mandir", "Manu River"].map((place) => (
            <li key={place}>
              <a href="#" className="text-cream/50 hover:text-gold text-sm transition-colors flex items-center gap-2 group">
                <ArrowRight size={12} className="text-saffron opacity-0 group-hover:opacity-100 transition-opacity" />
                {place}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </div>

    <div className="border-t border-gold/10 py-8 text-center px-6">
      <p className="font-heading text-[10px] tracking-[2px] text-cream/30 uppercase">
        🙏 JAI BALAJI · JAI SRI VENKATESWARA · OM NAMO NARAYANAYA 🙏
      </p>
      <p className="mt-2 text-[10px] text-cream/30">
        © 2024 Sringeri Balaji Mandir, Kailashahar, Unakoti, Tripura &nbsp;|&nbsp; Designed with devotion
      </p>
    </div>
  </footer>
);

const FloatingParticles = () => {
  const [particles, setParticles] = useState<any[]>([]);
  const emojis = ['🪔', '🌸', '🪷', '✨', '⭐', '🌟', '💫', '🔔'];

  useEffect(() => {
    const newParticles = Array.from({ length: 15 }).map((_, i) => ({
      id: i,
      emoji: emojis[Math.floor(Math.random() * emojis.length)],
      left: Math.random() * 100,
      duration: 8 + Math.random() * 15,
      delay: Math.random() * 15,
      size: 12 + Math.random() * 20
    }));
    setParticles(newParticles);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {particles.map(p => (
        <div 
          key={p.id}
          className="diya-particle"
          style={{
            left: `${p.left}vw`,
            animationDuration: `${p.duration}s`,
            animationDelay: `${p.delay}s`,
            fontSize: `${p.size}px`
          }}
        >
          {p.emoji}
        </div>
      ))}
    </div>
  );
};

// --- Main App ---

export default function App() {
  return (
    <div className="min-h-screen selection:bg-gold/30 selection:text-crimson-dark">
      <FloatingParticles />
      <Ticker />
      <Navbar />
      <Hero />
      <StatsBar />
      <About />
      <Deity />
      <Timings />
      <Festivals />
      <Reach />
      
      {/* Info Section */}
      <section id="contact" className="bg-gradient-to-br from-dark-brown to-[#0D0500] py-20 px-6">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ x: -50, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
          >
            <h2 className="font-display text-3xl text-gold mb-8">Temple Information & Contact</h2>
            <div className="space-y-6">
              {[
                { icon: <MapPin className="text-saffron-light" />, label: "Full Address", val: "Tirupati Balaji Temple, Pechardahar, Jalai, Bilaspur G.P., Fatikroy Constituency, Kailashahar, Unakoti District, Tripura – 799279" },
                { icon: <Clock className="text-saffron-light" />, label: "Darshan Hours", val: "Morning: 6:00 AM – 12:00 PM | Evening: 4:00 PM – 8:30 PM" },
                { icon: <Info className="text-saffron-light" />, label: "Affiliated With", val: "Sringeri Sharada Peetham (Founded by Adi Shankaracharya)" },
                { icon: <Home className="text-saffron-light" />, label: "Architecture", val: "South Indian Dravidian Style — modeled after Tirumala" }
              ].map((item, i) => (
                <div key={i} className="flex gap-4 items-start pb-6 border-b border-gold/15 last:border-none">
                  <div className="shrink-0 mt-1">{item.icon}</div>
                  <div>
                    <label className="block font-heading text-[10px] tracking-[2px] text-saffron-light uppercase mb-1">{item.label}</label>
                    <span className="text-cream/80 text-sm leading-relaxed">{item.val}</span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div 
            initial={{ x: 50, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <div className="bg-gradient-to-br from-gold/10 to-crimson/20 border-2 border-gold/30 rounded-xl h-[350px] flex flex-col items-center justify-center gap-4 text-center p-6">
              <MapPin size={56} className="text-gold" />
              <strong className="font-heading text-lg text-gold tracking-widest">Sringeri Balaji Mandir</strong>
              <span className="text-cream/60 text-sm">Pechardahar, Kailashahar<br/>Unakoti District, Tripura</span>
              <a 
                href="https://maps.google.com/?q=Tirupati+Balaji+Temple+Pechardahar+Kailashahar+Unakoti+Tripura" 
                target="_blank" 
                className="bg-gold text-dark font-heading text-[10px] tracking-widest px-6 py-3 rounded mt-2 hover:bg-gold-light transition-colors"
              >
                📍 Open in Google Maps
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />

      {/* Floating Action Buttons */}
      <div className="fixed bottom-8 right-8 z-[1000] flex flex-col gap-3">
        <a href="#home" className="w-12 h-12 rounded-full bg-gradient-to-br from-crimson-dark to-saffron text-white flex items-center justify-center shadow-xl hover:scale-110 transition-transform">
          <ChevronDown className="rotate-180" />
        </a>
        <a href="https://maps.google.com/?q=Tirupati+Balaji+Temple+Pechardahar+Kailashahar+Unakoti+Tripura" target="_blank" className="w-12 h-12 rounded-full bg-gradient-to-br from-crimson-dark to-saffron text-white flex items-center justify-center shadow-xl hover:scale-110 transition-transform">
          <MapPin size={20} />
        </a>
      </div>
    </div>
  );
}
